
import React from 'react';
import { Plus, MessageSquare, Trash2, X, BrainCircuit } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string, e: React.MouseEvent) => void;
  isOpen: boolean;
  setIsOpen: (v: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  onNewChat,
  onSelectChat,
  onDeleteChat,
  isOpen,
  setIsOpen
}) => {
  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 bg-black/60 z-40 md:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsOpen(false)}
      />

      {/* Sidebar Container */}
      <div 
        className={`
            fixed md:relative z-50 inset-y-0 left-0 
            bg-[#09090b] 
            flex flex-col 
            transform transition-all duration-300 ease-in-out
            ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
            ${isOpen ? 'md:w-[280px] border-r border-neutral-800' : 'md:w-0 md:overflow-hidden md:border-none'}
            w-[280px] h-full
        `}
      >
        <div className="w-[280px] h-full flex flex-col">
            {/* Header */}
            <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-cyan-900/30 text-cyan-400">
                    <BrainCircuit size={18} />
                </div>
                <span className="font-bold text-slate-200 text-sm tracking-tight">PROJECT-ELENCHOS</span>
            </div>
            {/* Mobile Close Button */}
            <button onClick={() => setIsOpen(false)} className="md:hidden text-neutral-400">
                <X size={20} />
            </button>
            </div>

            {/* New Chat Button */}
            <div className="px-4 mb-4">
            <button 
                onClick={() => {
                onNewChat();
                if (window.innerWidth < 768) setIsOpen(false);
                }}
                className="w-full flex items-center gap-3 bg-neutral-800 hover:bg-neutral-700 text-slate-200 px-4 py-3 rounded-xl transition-all border border-neutral-700 shadow-sm group"
            >
                <Plus size={18} className="group-hover:rotate-90 transition-transform duration-300" />
                <span className="text-sm font-medium">New Project</span>
            </button>
            </div>

            {/* History List */}
            <div className="flex-1 overflow-y-auto px-2 space-y-1 scrollbar-thin scrollbar-thumb-neutral-800">
            <div className="px-3 py-2 text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Projects</div>
            {sessions.map(session => (
                <div 
                key={session.id}
                onClick={() => {
                    onSelectChat(session.id);
                    if (window.innerWidth < 768) setIsOpen(false);
                }}
                className={`group flex items-center justify-between px-3 py-3 rounded-lg cursor-pointer transition-colors ${currentSessionId === session.id ? 'bg-neutral-800 text-slate-200' : 'text-neutral-400 hover:bg-neutral-900 hover:text-slate-300'}`}
                >
                <div className="flex items-center gap-3 overflow-hidden">
                    <MessageSquare size={14} className={currentSessionId === session.id ? 'text-cyan-400' : 'text-neutral-600'} />
                    <span className="text-sm truncate max-w-[160px]">{session.title}</span>
                </div>
                <button 
                    onClick={(e) => onDeleteChat(session.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-900/30 hover:text-red-400 rounded transition-all"
                >
                    <Trash2 size={12} />
                </button>
                </div>
            ))}
            {sessions.length === 0 && (
                <div className="px-4 py-8 text-center">
                <p className="text-neutral-600 text-xs italic">No project history.</p>
                </div>
            )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-neutral-800">
            <div className="flex items-center gap-3 text-neutral-500 text-xs">
                <div className="w-6 h-6 rounded-full bg-neutral-800 flex items-center justify-center text-[10px]">U</div>
                <span>System Architected by Uzair</span>
            </div>
            </div>
        </div>
      </div>
    </>
  );
};
