import { MemoryEntry, IndexEntry } from '../types';
import { getEmbedding, generateSummary } from './geminiService';

// Utility: Cosine Similarity
const cosineSimilarity = (vecA: number[], vecB: number[]): number => {
  const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0);
  const magA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0));
  const magB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0));
  return dotProduct / (magA * magB);
};

export class MemorySystem {
  private memories: MemoryEntry[] = [];
  private index: IndexEntry[] = [];
  
  // In a real app, you would load these from localStorage or a database
  constructor() {}

  getMemories = () => this.memories;
  getIndex = () => this.index;

  clear() {
    this.memories = [];
    this.index = [];
  }

  /**
   * 1. The Check & Retrieve
   * Checks the Index for relevant topics, then pulls from Neural Memory.
   */
  async recall(queryText: string): Promise<{ context: string; relevantIndexId: string | null }> {
    if (this.index.length === 0) {
      return { context: "", relevantIndexId: null };
    }

    const queryEmbedding = await getEmbedding(queryText);
    
    // Find best matching topic in the Index
    let bestMatch: IndexEntry | null = null;
    let maxScore = -1;

    for (const entry of this.index) {
      const score = cosineSimilarity(queryEmbedding, entry.summaryEmbedding);
      // Threshold for topic relevance
      if (score > 0.65 && score > maxScore) {
        maxScore = score;
        bestMatch = entry;
      }
    }

    if (!bestMatch) {
      return { context: "", relevantIndexId: null };
    }

    // Retrieve actual content from Neural Memory using Location_IDs
    const relevantContent = bestMatch.locationIds
      .map(id => this.memories.find(m => m.id === id))
      .filter(Boolean)
      .map(m => `- ${m?.content}`)
      .join("\n");

    return { 
      context: `Relevant Topic: ${bestMatch.summary}\nMemories:\n${relevantContent}`,
      relevantIndexId: bestMatch.id 
    };
  }

  /**
   * 2. The Update (Growing Part)
   * Stores full content in Neural Memory, then updates Index.
   */
  async memorize(text: string, existingIndexId: string | null): Promise<void> {
    // 1. Store in Neural Memory (Vector Store)
    const embedding = await getEmbedding(text);
    const memoryId = crypto.randomUUID();
    
    const newMemory: MemoryEntry = {
      id: memoryId,
      content: text,
      embedding: embedding,
      timestamp: Date.now(),
    };
    
    this.memories = [...this.memories, newMemory];

    // 2. Update The Index (The Router)
    if (existingIndexId) {
      // Add to existing topic
      this.index = this.index.map(entry => {
        if (entry.id === existingIndexId) {
          return {
            ...entry,
            locationIds: [...entry.locationIds, memoryId],
            timestamp: Date.now()
          };
        }
        return entry;
      });
    } else {
      // Create new topic in Index
      // We need to check if this strictly belongs to a new topic or if the 'existingIndexId' was null just because of low score.
      // For this simple architecture, if retrieval failed (score < threshold), we create a new topic.
      
      const summary = await generateSummary(text);
      const summaryEmbedding = await getEmbedding(summary);
      
      const newIndexEntry: IndexEntry = {
        id: crypto.randomUUID(),
        summary: summary,
        summaryEmbedding: summaryEmbedding,
        locationIds: [memoryId],
        timestamp: Date.now()
      };

      this.index = [...this.index, newIndexEntry];
    }
  }
}

// Singleton instance for the demo
export const memorySystem = new MemorySystem();