
export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachment?: {
    type: 'image' | 'audio' | 'video';
    data: string; // base64 or url
    mimeType?: string;
  };
  sources?: { title: string; uri: string }[];
}

// The "Neural Memory" Unit
export interface MemoryEntry {
  id: string;
  content: string;
  embedding: number[];
  timestamp: number;
}

// The "Index/Router" Unit
export interface IndexEntry {
  id: string;
  summary: string;
  summaryEmbedding: number[]; // Used to find the right topic
  locationIds: string[]; // Pointers to Neural Memory
  timestamp: number;
}

export interface ProcessingStatus {
  stage: 'idle' | 'embedding' | 'checking-index' | 'retrieving' | 'generating' | 'updating-memory' | 'generating-image' | 'generating-audio' | 'generating-video';
  details?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: number;
  codingStep?: number; // Save progress for coding mode
  isCodingMode?: boolean;
  isStudioMode?: boolean; // Save state for Studio mode
}
