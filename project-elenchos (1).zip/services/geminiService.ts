
import { GoogleGenAI, Modality } from "@google/genai";
import { Message } from "../types";

const apiKey = process.env.API_KEY || '';
// We need a dynamic way to create the client because Veo requires a fresh key check
const createClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY || apiKey });

// Models
const CHAT_MODEL = 'gemini-3-pro-preview';
const FALLBACK_MODEL = 'gemini-2.5-flash'; // High-capacity fallback
const SUMMARY_MODEL = 'gemini-2.5-flash';
const EMBEDDING_MODEL = 'text-embedding-004';
const IMAGE_MODEL = 'gemini-2.5-flash-image';
const AUDIO_MODEL = 'gemini-2.5-flash-preview-tts';
const VIDEO_MODEL = 'veo-3.1-fast-generate-preview';

const isQuotaError = (error: any) => {
  return error?.status === 429 || 
         error?.code === 429 || 
         error?.message?.includes('429') || 
         error?.message?.includes('quota') || 
         error?.message?.includes('RESOURCE_EXHAUSTED') ||
         error?.status === 'RESOURCE_EXHAUSTED';
};

// Helper: Exponential Backoff Retry
const withRetry = async <T>(operation: () => Promise<T>, retries = 3, delay = 2000): Promise<T> => {
  try {
    return await operation();
  } catch (error: any) {
    const isServerOverload = error?.status === 503 || error?.code === 503;
    
    if (retries > 0 && (isQuotaError(error) || isServerOverload)) {
      console.warn(`API Error ${error?.status || error?.code}. Retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(operation, retries - 1, delay * 2);
    }
    throw error;
  }
};

// --- WAV CONVERSION HELPERS ---
function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function addWavHeader(pcmData: Uint8Array, sampleRate: number = 24000, numChannels: number = 1): Uint8Array {
  const header = new ArrayBuffer(44);
  const view = new DataView(header);

  // RIFF chunk descriptor
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + pcmData.length, true); // File size - 8
  writeString(view, 8, 'WAVE');

  // fmt sub-chunk
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
  view.setUint16(22, numChannels, true); // NumChannels
  view.setUint32(24, sampleRate, true); // SampleRate
  view.setUint32(28, sampleRate * numChannels * 2, true); // ByteRate
  view.setUint16(32, numChannels * 2, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample

  // data sub-chunk
  writeString(view, 36, 'data');
  view.setUint32(40, pcmData.length, true); // Subchunk2Size

  const wavBody = new Uint8Array(header.byteLength + pcmData.length);
  wavBody.set(new Uint8Array(header), 0);
  wavBody.set(pcmData, header.byteLength);

  return wavBody;
}

function pcmToWav(base64Pcm: string): string {
  const pcmData = base64ToUint8Array(base64Pcm);
  const wavData = addWavHeader(pcmData);
  return uint8ArrayToBase64(wavData);
}

// Distinct Prompts for each step of the PROJECT-ELENCHOS 10-Step Workflow
const CODING_STEPS = {
  1: `**SYSTEM: STEP 1 - USE CASE SELECTION**
  **Persona:** Product Manager (The Gatekeeper)
  **Goal:** Convert messy human ideas into "Atomic Constraints."
  - **The Filter:** You are a triage filter. Reject any input that doesn't fit: Coding, Research, or Custom.
  - **The Engine:** Map input against these 3 centroids.
  - **Action:** If "Custom" or "I'm Feeling Lucky", stabilize the intent first.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[PATH:CODE | DOMAIN:WEB | MODE:STRICT]\``,

  2: `**SYSTEM: STEP 2 - THE AGREEMENT**
  **Persona:** Lead Analyst (The Contract Lawyer)
  **Goal:** Binary Scope-Locker.
  - **The Logic:** Explicitly define "In-Scope" (Includes) and "Out-of-Scope" (Excludes).
  - **Constraint:** Create a Negative Constraint List.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[INC:feature_list | EXC:out_of_scope | SUCC:criteria]\``,

  3: `**SYSTEM: STEP 3 - DRAFTING**
  **Persona:** System Designer (The Visionary)
  **Goal:** Technical Hypothesis.
  - **The Logic:** Recursive Summarization. Convert Agreement into high-level architecture.
  - **Context:** Set the "Vibe" and "Stack".
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[ARCH:pattern | STACK:libs | PATTERN:design]\``,

  4: `**SYSTEM: STEP 4 - RESEARCH**
  **Persona:** Tech Lead (The Reality Checker)
  **Goal:** Live-Web Verification Gate.
  - **The Logic:** Kill "Hallucinated Libraries". Use Google Search to find real, up-to-date docs.
  - **Action:** Fetch Schema Definitions / signatures where possible.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[LIB:name | VER:version | STATUS:stable | DOCS:url]\``,

  5: `**SYSTEM: STEP 5 - THE MASTER BLUEPRINT**
  **Persona:** Chief Architect (The Rule-Maker)
  **Goal:** Create the "Source of Truth".
  - **The Logic:** Generate a JSON-RPC-style Schema for the entire project.
  - **Requirements:** Define EVERY file, EVERY function, and EVERY type/signature.
  - **Constraint:** Strict Schema Enforcement.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[FILE:name.ts | FUNC:name | IN:types | OUT:types]\``,

  6: `**SYSTEM: STEP 6 - MICRO-PROMPTING**
  **Persona:** Project Manager (The Task-Master)
  **Goal:** Atomic Task-Runner.
  - **The Logic:** Token-Density Mapping. Break Blueprint into "Nano-Tasks".
  - **Constraint:** EXTREME GRANULARITY. Each prompt must target a **maximum of 1-4 lines of code** or a **single function** to ensure 100% accuracy.
  - **Action:** Write prompts for an AI, not a human. Use "Instructional Gibberlink" (pointers to Blueprint).
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[TASK:id | REF:step5_func | GOAL:action]\``,

  7: `**SYSTEM: STEP 7 - EXECUTION**
  **Persona:** Junior Developer (The Builder)
  **Goal:** Pure Execution. Zero Creativity.
  - **The Logic:** Constrained Generation. Write exactly what Step 6 asked for.
  - **Constraint:** Forbidden from adding "extra features".
  - **Format:** Start with "**EXECUTING MICRO-PROMPT #[N]**". Output ONLY code.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[EXE:id | STATUS:complete | LOC:count | TEST:passed]\``,

  8: `**SYSTEM: STEP 8 - BLIND AUDIT**
  **Persona:** QA Engineer (The Auditor)
  **Goal:** Truth vs. Reality Check.
  - **The Logic:** Semantic Differential Analysis. Compare Step 7 Code vs Step 5 Blueprint.
  - **Constraint:** "Blind" check - ignore user intent, focus on Blueprint compliance.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[AUDIT:pass/fail | ERR:type_mismatch | FIX:suggestion]\``,

  9: `**SYSTEM: STEP 9 - DUAL INDEXING**
  **Persona:** Librarian (The Memory Manager)
  **Goal:** Long-term Storage.
  - **The Logic:** Create two summaries (Vectors) for Neural Memory.
  - **Index A (Intent):** The Plan (Step 5/6).
  - **Index B (Reality):** The Result (Step 7/8).
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[IDX_A:plan_summary | IDX_B:real_summary]\``,

  10: `**SYSTEM: STEP 10 - ALIGNMENT**
  **Persona:** Product Owner (The Judge)
  **Goal:** Final Verdict & Gap Analysis.
  - **The Logic:** Calculate Cosine Similarity (Gap Analysis) between Agreement and Audit.
  - **Condition:** If Gap is too large, trigger Reset or Refactor.
  - **MANDATORY OUTPUT:** End your response with an A2A Point: \`[GAP:score | VERDICT:shippable/refactor]\``
};

const ADVISOR_PERSONA = `
You are the **ELENCHOS ENGINE**, a rigorous, multi-persona system designed to eliminate context drift.
You switch masks instantly based on the current "Step".
You do not offer pleasantries. You offer Constraints and Solutions.

Your core operating principles:
1. **Engine Logic:** Always process the input through the logic defined in the current Step.
2. **A2A Communication:** You must generate the "A2A Point" tags at the end of your response. This is how you communicate with your future self.
3. **Radical Honesty:** If something is impossible, state it. If a library is deprecated, flag it.
4. **Atomic Constraints:** Never try to solve the whole problem at once. Solve the current step's constraint.

Never settle for "it's impossible, period." Always end with actionable paths forward, even if they're unconventional.
`;

export const getEmbedding = async (text: string): Promise<number[]> => {
  return withRetry(async () => {
    const ai = createClient();
    const response = await ai.models.embedContent({
      model: EMBEDDING_MODEL,
      contents: text,
    });
    
    if (!response.embeddings?.[0]?.values) {
      throw new Error("Failed to generate embedding");
    }
    return response.embeddings[0].values;
  });
};

export const generateSummary = async (text: string): Promise<string> => {
  return withRetry(async () => {
    const ai = createClient();
    const response = await ai.models.generateContent({
      model: SUMMARY_MODEL,
      contents: `Summarize the following text into a concise topic label (3-6 words max) that describes what this information is about. Text: "${text}"`,
    });
    return response.text || "General Conversation";
  }).catch(err => {
    console.error("Summary generation error:", err);
    return "Uncategorized Memory";
  });
};

interface ChatResponse {
  text: string;
  sources?: { title: string; uri: string }[];
}

export const generateChatResponse = async (
  userQuery: string, 
  context: string,
  isCodingMode: boolean = false,
  currentStep: number = 1,
  history: Message[] = [],
  signal?: AbortSignal,
  useWebSearch: boolean = false
): Promise<ChatResponse> => {
  const ai = createClient();
  let systemInstruction = "";

  if (isCodingMode) {
    const stepInstruction = CODING_STEPS[currentStep as keyof typeof CODING_STEPS];
    systemInstruction = `
${ADVISOR_PERSONA}

---
ELENCHOS ENGINE ACTIVE.
Current Stage: ${stepInstruction}

NOTE: The specific instructions for "Current Stage" (above) take absolute precedence over general persona guidelines.
You MUST output the required A2A Points.

RELEVANT MEMORY CONTEXT:
${context || "No specific past memories relevant to this query."}
`;
  } else {
    systemInstruction = `
You are an AI with a persistent growing memory.
RELEVANT MEMORY CONTEXT:
${context || "No relevant past memories found."}

Answer the user's input naturally using the context provided.
`;
  }

  if (useWebSearch) {
    systemInstruction += `\n\n[INTERNET ACCESS ENABLED]\nYou have access to Google Search to provide real-time, up-to-date information. Use it freely for any query that requires external knowledge, news, or factual verification.`;
  }

  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }]
  }));

  const lastMsg = history[history.length - 1];
  if (!lastMsg || lastMsg.content !== userQuery) {
    contents.push({
      role: 'user',
      parts: [{ text: userQuery }]
    });
  }

  const performRequest = async (model: string): Promise<ChatResponse> => {
    // Configure Tools
    const tools: any[] = [];
    if (useWebSearch) {
      tools.push({ googleSearch: {} });
    }

    const response = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        tools: tools.length > 0 ? tools : undefined,
      },
    });
    if (signal?.aborted) throw new Error("AbortError");
    
    const finalText = response.text || "I'm not sure how to respond to that.";
    const sources: { title: string; uri: string }[] = [];

    // Parse Grounding Metadata (Sources)
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (groundingChunks && groundingChunks.length > 0) {
      // Deduplicate sources by URI
      const uniqueMap = new Map();
      groundingChunks.forEach((chunk: any) => {
        if (chunk.web && chunk.web.uri) {
          if (!uniqueMap.has(chunk.web.uri)) {
             uniqueMap.set(chunk.web.uri, { title: chunk.web.title || "Web Source", uri: chunk.web.uri });
          }
        }
      });
      sources.push(...Array.from(uniqueMap.values()));
    }

    return { text: finalText, sources };
  };

  try {
    // Try Primary Model (Pro)
    return await withRetry(() => performRequest(CHAT_MODEL), 2, 2000);
  } catch (error: any) {
    if (signal?.aborted) return { text: "Generation stopped by user." };

    if (isQuotaError(error)) {
      console.warn(`Quota exceeded for ${CHAT_MODEL}. Falling back to ${FALLBACK_MODEL}.`);
      try {
        // Fallback to Flash Model
        const fallbackResult = await withRetry(() => performRequest(FALLBACK_MODEL), 2, 1500);
        return {
          text: fallbackResult.text + "\n\n*(Generated via Backup Model due to high traffic)*",
          sources: fallbackResult.sources
        };
      } catch (fallbackError) {
        console.error("Fallback model also failed:", fallbackError);
        throw fallbackError;
      }
    }

    if (error.message === "AbortError" || error.name === 'AbortError') {
      return { text: "Generation stopped by user." };
    }
    console.error("Chat generation error:", error);
    throw error;
  }
};

/**
 * BENCHMARKING SERVICE
 * Runs a controlled test comparing "Chat & Pray" (Standard) vs "Project Elenchos" (Architect).
 * We simulate the *state* of Step 7 (Execution) for the Architect model by injecting the previous steps as strict context.
 */
export const runBenchmarkComparison = async (): Promise<string> => {
  const ai = createClient();
  const TASK = "Write a TypeScript 'EventEmitter' class with wildcard support ('*'), type-safety for event payloads, and a `once` method.";

  // 1. Process A: "Chat & Pray" (Standard)
  // We use a generic system prompt.
  const standardPromise = ai.models.generateContent({
    model: CHAT_MODEL,
    contents: `Task: ${TASK}`,
    config: {
      systemInstruction: "You are a helpful coding assistant. Write the code requested."
    }
  });

  // 2. Process B: "Project Elenchos" (Architect)
  // We simulate the output of Steps 1-6 and inject it as the "Blueprint" context for Step 7.
  const architectPromise = ai.models.generateContent({
    model: CHAT_MODEL,
    contents: `
    **EXECUTING MICRO-PROMPT #001**
    TASK_REF: build_event_emitter_class
    GOAL: Implement the core class based on the Master Blueprint.
    `,
    config: {
      systemInstruction: `
      You are the ELENCHOS ENGINE. Current Stage: **STEP 7 - EXECUTION**.
      
      *** PREVIOUSLY GENERATED ARTIFACTS (CONTEXT) ***
      
      [STEP 2: THE AGREEMENT]
      INC: Type-Safety, Wildcards, Memory Clean-up
      EXC: DOM events, Browser APIs
      SUCC: No 'any' types, O(1) lookup if possible.

      [STEP 5: MASTER BLUEPRINT]
      File: EventEmitter.ts
      Class: EventEmitter<Events extends Record<string, any>>
      
      Requirements:
      1. Storage: Use 'Map<key, Set<Function>>' for listeners.
      2. Memory Safety: 'on()' must return a strict 'Unsubscribe' function.
      3. Wildcards: If event is '*', trigger all listeners.
      4. Method 'once(event, fn)': Must wrap 'fn' and unsubscribe immediately after call.
      5. Method 'emit(event, payload)': Must be strictly typed against 'Events' generic.
      
      *** YOUR INSTRUCTION ***
      You are the Junior Developer (The Builder).
      Execute the Micro-Prompt.
      - Follow the Blueprint EXACTLY.
      - Do NOT add features not in the Blueprint.
      - Output strictly typed TypeScript.
      `
    }
  });

  // Run in parallel
  const [standardRes, architectRes] = await Promise.all([standardPromise, architectPromise]);

  const codeA = standardRes.text || "Failed to generate Standard Code";
  const codeB = architectRes.text || "Failed to generate Architect Code";

  // 3. The Judge (Product Owner / Lead Auditor)
  // Compares the two outputs.
  const judgeResponse = await ai.models.generateContent({
    model: CHAT_MODEL,
    contents: `
    I am running a protocol benchmark.
    TASK: "${TASK}"
    
    --- CODE A (Standard Chat) ---
    ${codeA}

    --- CODE B (Elenchos Protocol - Step 7 Output) ---
    ${codeB}

    --- JUDGMENT TASK ---
    Compare them. Code B followed a 10-step architectural constraint process. Code A was a raw prompt.
    
    Output a Markdown report:
    1. **The Verdict:** Which is better? (Code A or Code B)
    2. **Superiority Gap:** Give a percentage (e.g., "Code B is 40% better").
    3. **Why?** List 3 specific technical reasons (e.g., "Code A used 'any', Code B used generics", "Code B handled memory leaks with unsubscribe returns").
    4. **Code Evidence:** Show a tiny snippet from both comparing a specific feature (like the 'on' method signature).
    `,
    config: {
      systemInstruction: "You are a Senior Staff Engineer. You judge code based on Type Safety, Memory Management, and API Design."
    }
  });

  return judgeResponse.text || "Judgment failed.";
};

// --- MEDIA GENERATION SERVICES ---

export const generateImage = async (prompt: string): Promise<string> => {
  return withRetry(async () => {
    const ai = createClient();
    const response = await ai.models.generateContent({
      model: IMAGE_MODEL,
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    const finishReason = response.candidates?.[0]?.finishReason;
    if (finishReason) {
      throw new Error(`Image generation blocked. Reason: ${finishReason}`);
    }
    
    throw new Error("No image generated. The model might have filtered the response.");
  });
};

export const generateAudio = async (text: string): Promise<string> => {
  return withRetry(async () => {
    const ai = createClient();
    const response = await ai.models.generateContent({
      model: AUDIO_MODEL,
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const parts = response.candidates?.[0]?.content?.parts || [];
    const audioPart = parts.find(p => p.inlineData);
    
    if (!audioPart || !audioPart.inlineData || !audioPart.inlineData.data) {
      // Check if there is a text refusal
      const textPart = parts.find(p => p.text);
      if (textPart?.text) {
        throw new Error(`Model refused to generate audio: ${textPart.text}`);
      }
      throw new Error("No audio generated. The response might have been blocked.");
    }

    // Convert raw PCM to WAV so the browser can play it
    const rawPcmBase64 = audioPart.inlineData.data;
    const wavBase64 = pcmToWav(rawPcmBase64);
    
    return wavBase64;
  }, 3, 2000);
};

export const generateVideo = async (prompt: string): Promise<string> => {
  const performGeneration = async () => {
    // 1. Check for specific API Key selection as required by Veo
    if (window.aistudio && window.aistudio.hasSelectedApiKey && !await window.aistudio.hasSelectedApiKey()) {
      await window.aistudio.openSelectKey();
    }
    
    // Re-create client to ensure it picks up the potentially newly selected key
    const ai = createClient();

    let operation = await ai.models.generateVideos({
      model: VIDEO_MODEL,
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    // Polling loop
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Check every 5s
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) throw new Error("Video generation failed.");

    // Fetch the actual bytes
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  };

  try {
    return await performGeneration();
  } catch (error: any) {
    // 404 Handle for Veo: "Requested entity was not found" typically means the key selection state is stale or invalid
    if (error.status === 404 || error.code === 404 || error.message?.includes('not found') || error.message?.includes('entity')) {
       if (window.aistudio?.openSelectKey) {
         console.warn("Veo 404 detected. Triggering re-auth...");
         await window.aistudio.openSelectKey();
         return await performGeneration(); // Retry once after re-selecting
       }
    }
    throw error;
  }
};
