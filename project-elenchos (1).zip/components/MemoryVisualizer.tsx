
import React, { useState, useEffect, useRef } from 'react';
import { MemoryEntry, IndexEntry } from '../types';
import { Code, Share2, Activity, Zap } from 'lucide-react';

interface MemoryVisualizerProps {
  memories: MemoryEntry[];
  index: IndexEntry[];
  activeTopicId: string | null;
}

// Internal types for the physics engine
interface Node {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  label?: string;
  type: 'hub' | 'leaf';
  originalData?: any;
}

interface Link {
  source: string; // ID
  target: string; // ID
}

export const MemoryVisualizer: React.FC<MemoryVisualizerProps> = ({ 
  memories, 
  index,
  activeTopicId
}) => {
  const [viewMode, setViewMode] = useState<'graph' | 'raw'>('graph');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Physics State
  const simulationState = useRef<{ nodes: Node[], links: Link[] }>({ nodes: [], links: [] });
  const requestRef = useRef<number>(0);
  
  // Interaction State
  const [hoveredNode, setHoveredNode] = useState<Node | null>(null);
  const dragRef = useRef<{ node: Node, startX: number, startY: number } | null>(null);
  const mouseRef = useRef<{ x: number, y: number }>({ x: 0, y: 0 });

  // Physics Constants - Tuned for "Organic" Feel
  const PHYSICS = {
    repulsion: 1200,      // Separation force
    springLength: 70,     // Ideal link length
    springStrength: 0.03, // Elasticity
    damping: 0.90,        // Friction (0.90 = fluid, 0.50 = soup)
    centering: 0.002,     // Weak pull to center
    maxVelocity: 12       // Cap speed to prevent explosions
  };

  // Helper: Format raw data
  const getRawData = () => {
    const safeMemories = memories.map(m => ({
      ...m,
      embedding: `[Array(${m.embedding.length}) - Truncated]`
    }));
    const safeIndex = index.map(i => ({
      ...i,
      summaryEmbedding: `[Array(${i.summaryEmbedding.length}) - Truncated]`
    }));
    return JSON.stringify({ index: safeIndex, neural_storage: safeMemories }, null, 2);
  };

  // 1. Initialize Simulation Data
  useEffect(() => {
    if (!containerRef.current) return;
    
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;
    
    const prevNodes = simulationState.current.nodes;
    const newNodes: Node[] = [];
    const newLinks: Link[] = [];

    // Create Hubs (Topics)
    index.forEach((entry) => {
      const existing = prevNodes.find(n => n.id === entry.id);
      newNodes.push({
        id: entry.id,
        x: existing ? existing.x : width / 2 + (Math.random() - 0.5) * 50,
        y: existing ? existing.y : height / 2 + (Math.random() - 0.5) * 50,
        vx: existing ? existing.vx : 0,
        vy: existing ? existing.vy : 0,
        radius: Math.max(14, 10 + (entry.locationIds.length * 1.5)), 
        color: activeTopicId === entry.id ? '#a3e635' : '#10b981', // Lime-400 vs Emerald-500
        label: entry.summary,
        type: 'hub',
        originalData: entry
      });
    });

    // Create Leaves (Memories)
    memories.forEach((mem) => {
      const existing = prevNodes.find(n => n.id === mem.id);
      
      // Find parent hub for initial placement
      let parentHubId = null;
      index.forEach(idx => {
        if (idx.locationIds.includes(mem.id)) parentHubId = idx.id;
      });
      const parentNode = newNodes.find(n => n.id === parentHubId);

      newNodes.push({
        id: mem.id,
        x: existing ? existing.x : (parentNode ? parentNode.x + (Math.random()-0.5)*40 : width/2 + (Math.random()-0.5)*150),
        y: existing ? existing.y : (parentNode ? parentNode.y + (Math.random()-0.5)*40 : height/2 + (Math.random()-0.5)*150),
        vx: existing ? existing.vx : 0,
        vy: existing ? existing.vy : 0,
        radius: 5,
        color: '#3b82f6', // Blue-500
        type: 'leaf',
        originalData: mem
      });

      if (parentHubId) {
        newLinks.push({ source: parentHubId, target: mem.id });
      }
    });

    simulationState.current = { nodes: newNodes, links: newLinks };
  }, [memories, index, activeTopicId]);

  // 2. Animation Loop
  useEffect(() => {
    if (viewMode !== 'graph') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;

    const animate = () => {
      time += 0.05;
      const { nodes, links } = simulationState.current;
      const width = canvas.width;
      const height = canvas.height;

      // --- Physics Integration ---
      
      // 1. Repulsion (O(n^2) - Keep n small or optimize with Quadtree)
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const distSq = dx * dx + dy * dy || 0.1;
          const dist = Math.sqrt(distSq);
          
          // Force strength
          const force = PHYSICS.repulsion / distSq;
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;

          if (!dragRef.current || dragRef.current.node !== a) {
             a.vx -= fx;
             a.vy -= fy;
          }
          if (!dragRef.current || dragRef.current.node !== b) {
             b.vx += fx;
             b.vy += fy;
          }
        }
      }

      // 2. Attraction (Springs)
      links.forEach(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        if (source && target) {
          const dx = target.x - source.x;
          const dy = target.y - source.y;
          const dist = Math.sqrt(dx*dx + dy*dy) || 0.1;
          
          const force = (dist - PHYSICS.springLength) * PHYSICS.springStrength;
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;

          if (!dragRef.current || dragRef.current.node !== source) {
             source.vx += fx;
             source.vy += fy;
          }
          if (!dragRef.current || dragRef.current.node !== target) {
             target.vx -= fx;
             target.vy -= fy;
          }
        }
      });

      // 3. Update Positions & Drag Handling
      nodes.forEach(node => {
        // Dragging Override
        if (dragRef.current && dragRef.current.node.id === node.id) {
           node.x = mouseRef.current.x;
           node.y = mouseRef.current.y;
           node.vx = 0;
           node.vy = 0;
           return;
        }

        // Center Gravity
        node.vx += (width/2 - node.x) * PHYSICS.centering;
        node.vy += (height/2 - node.y) * PHYSICS.centering;

        // Damping
        node.vx *= PHYSICS.damping;
        node.vy *= PHYSICS.damping;

        // Velocity Cap
        const vSq = node.vx*node.vx + node.vy*node.vy;
        if (vSq > PHYSICS.maxVelocity*PHYSICS.maxVelocity) {
           const v = Math.sqrt(vSq);
           node.vx = (node.vx / v) * PHYSICS.maxVelocity;
           node.vy = (node.vy / v) * PHYSICS.maxVelocity;
        }

        node.x += node.vx;
        node.y += node.vy;

        // Boundaries
        const pad = node.radius + 15;
        if (node.x < pad) { node.x = pad; node.vx *= -0.5; }
        if (node.x > width - pad) { node.x = width - pad; node.vx *= -0.5; }
        if (node.y < pad) { node.y = pad; node.vy *= -0.5; }
        if (node.y > height - pad) { node.y = height - pad; node.vy *= -0.5; }
      });

      // --- Rendering ---
      ctx.clearRect(0, 0, width, height);

      // Draw Synapses (Links)
      ctx.globalCompositeOperation = 'screen';
      links.forEach(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        if (source && target) {
          ctx.beginPath();
          const grad = ctx.createLinearGradient(source.x, source.y, target.x, target.y);
          grad.addColorStop(0, `${source.color}40`); // 25% opacity
          grad.addColorStop(1, `${target.color}40`);
          ctx.strokeStyle = grad;
          ctx.lineWidth = 2;
          ctx.moveTo(source.x, source.y);
          ctx.lineTo(target.x, target.y);
          ctx.stroke();
        }
      });
      ctx.globalCompositeOperation = 'source-over';

      // Draw Nodes
      nodes.forEach(node => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        
        // Node Gradient
        const rGrad = ctx.createRadialGradient(node.x, node.y, node.radius * 0.2, node.x, node.y, node.radius);
        rGrad.addColorStop(0, node.color);
        rGrad.addColorStop(1, adjustColor(node.color, -30)); // Darken edge
        ctx.fillStyle = rGrad;
        
        // Glow
        ctx.shadowBlur = node.type === 'hub' ? 20 : 10;
        ctx.shadowColor = node.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Border
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = node.type === 'hub' ? 1.5 : 0.5;
        ctx.stroke();

        // Label for Hubs
        if (node.type === 'hub' && node.label) {
          ctx.fillStyle = '#e2e8f0';
          ctx.font = 'bold 11px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          // Label bg
          const metrics = ctx.measureText(node.label);
          ctx.fillStyle = 'rgba(0,0,0,0.6)';
          ctx.fillRect(node.x - metrics.width/2 - 4, node.y - node.radius - 20, metrics.width + 8, 16);
          // Label text
          ctx.fillStyle = '#fff';
          ctx.fillText(node.label, node.x, node.y - node.radius - 12);
        }
      });

      requestRef.current = requestAnimationFrame(animate);
    };

    // Resize Handler
    const handleResize = () => {
        if (containerRef.current && canvasRef.current) {
            canvasRef.current.width = containerRef.current.clientWidth;
            canvasRef.current.height = containerRef.current.clientHeight;
        }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    
    requestRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(requestRef.current);
    };
  }, [viewMode]);

  // Color Utility
  function adjustColor(color: string, amount: number) {
      return color; // Simplification for demo
  }

  // --- Input Handlers ---

  const getMousePos = (e: React.MouseEvent) => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (viewMode !== 'graph') return;
    const { x, y } = getMousePos(e);
    
    // Hit Test
    const hitNode = simulationState.current.nodes.find(node => {
      const dist = Math.sqrt((node.x - x)**2 + (node.y - y)**2);
      return dist < node.radius + 8; // generous hit area
    });

    if (hitNode) {
      dragRef.current = { node: hitNode, startX: x, startY: y };
      mouseRef.current = { x, y };
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (viewMode !== 'graph') return;
    const { x, y } = getMousePos(e);
    mouseRef.current = { x, y };

    if (dragRef.current) return; // If dragging, we don't need to hover check as aggressively

    // Hover check
    const hitNode = simulationState.current.nodes.find(node => {
      const dist = Math.sqrt((node.x - x)**2 + (node.y - y)**2);
      return dist < node.radius + 8;
    });
    setHoveredNode(hitNode || null);
  };

  const handleMouseUp = () => {
    dragRef.current = null;
  };

  return (
    <div className="flex flex-col h-full bg-neutral-900/80 backdrop-blur-md rounded-2xl shadow-2xl border border-neutral-800 overflow-hidden relative">
      {/* Header */}
      <div className="p-4 border-b border-neutral-800 bg-neutral-900/50 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <Activity size={18} className="text-emerald-500 animate-pulse" />
          <h2 className="font-semibold text-slate-200 text-sm">Neural Cortex Map</h2>
          <span className="text-xs text-neutral-500 font-mono hidden sm:inline">
             Active Nodes: {memories.length}
          </span>
        </div>
        <div className="flex gap-1 bg-neutral-800 p-1 rounded-lg">
           <button 
             onClick={() => setViewMode('graph')}
             className={`p-1.5 rounded transition-all ${viewMode === 'graph' ? 'bg-neutral-700 text-emerald-400 shadow-sm' : 'text-neutral-400 hover:text-emerald-400'}`}
             title="Interactive Graph"
           >
             <Share2 size={16} />
           </button>
           <button 
             onClick={() => setViewMode('raw')}
             className={`p-1.5 rounded transition-all ${viewMode === 'raw' ? 'bg-neutral-700 text-cyan-400 shadow-sm' : 'text-neutral-400 hover:text-cyan-400'}`}
             title="JSON Data"
           >
             <Code size={16} />
           </button>
        </div>
      </div>

      {/* Canvas Layer */}
      <div className="flex-1 relative overflow-hidden bg-[#050505]" ref={containerRef}>
        {viewMode === 'graph' ? (
          <>
            <canvas 
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={() => {
                handleMouseUp();
                setHoveredNode(null);
              }}
              className="block w-full h-full cursor-grab active:cursor-grabbing"
            />
            
            {/* Overlay UI for Hover */}
            {hoveredNode && (
               <div 
                 className="absolute pointer-events-none bg-neutral-900/95 backdrop-blur border border-neutral-700 p-3 rounded-lg shadow-[0_10px_40px_rgba(0,0,0,0.5)] z-20 max-w-[280px] animate-in fade-in zoom-in-95 duration-200"
                 style={{ 
                   left: Math.min(hoveredNode.x + 20, (containerRef.current?.clientWidth || 500) - 300), 
                   top: Math.min(hoveredNode.y - 20, (containerRef.current?.clientHeight || 500) - 150),
                 }}
               >
                 <div className="flex items-center gap-2 mb-2">
                   <div className={`w-2.5 h-2.5 rounded-full ${hoveredNode.type === 'hub' ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-blue-500 shadow-[0_0_10px_#3b82f6]'}`} />
                   <span className="text-xs font-bold text-slate-100 uppercase tracking-wider">{hoveredNode.type} NODE</span>
                 </div>
                 <p className="text-xs text-slate-300 leading-relaxed font-mono">
                   {hoveredNode.type === 'hub' ? hoveredNode.label : (hoveredNode.originalData.content.slice(0, 100) + '...')}
                 </p>
                 <div className="mt-2 pt-2 border-t border-neutral-800 flex justify-between items-center text-[10px] text-neutral-500 font-mono">
                    <span>ID: {hoveredNode.id.slice(0,6)}</span>
                    <span className="flex items-center gap-1"><Zap size={10} /> Live</span>
                 </div>
               </div>
            )}
            
            {/* Help Text */}
            <div className="absolute bottom-4 left-4 text-[10px] text-neutral-600 font-mono pointer-events-none select-none">
               DRAG NODES TO REARRANGE • SCROLL TO ZOOM (WIP)
            </div>
          </>
        ) : (
          <div className="w-full h-full p-0 overflow-auto bg-[#0d1117] scrollbar-thin scrollbar-thumb-neutral-700">
            <div className="p-4">
              <pre className="text-xs font-mono text-cyan-300 leading-5">
                {getRawData()}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
