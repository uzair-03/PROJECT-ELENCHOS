
import React, { useState, useRef, useEffect } from 'react';
import { ChatArea } from './components/ChatArea';
import { Sidebar } from './components/Sidebar';
import { MemoryVisualizer } from './components/MemoryVisualizer';
import { Message, ProcessingStatus, ChatSession } from './types';
import { memorySystem } from './services/vectorStore';
import { generateChatResponse, runBenchmarkComparison, generateImage } from './services/geminiService'; // kept generateImage just in case, but unused in logic
import { Trash2, Save, Play, Pause, Menu, ArrowRight, Activity, PanelLeft, FlaskConical } from 'lucide-react';

const StarField = () => {
  const stars = Array.from({ length: 50 }).map((_, i) => ({
    id: i,
    top: `${Math.floor(Math.random() * 100)}%`,
    left: `${Math.floor(Math.random() * 100)}%`,
    size: `${Math.random() * 2 + 1}px`,
    duration: `${Math.random() * 3 + 2}s`,
    delay: `${Math.random() * 5}s`,
    opacity: Math.random() * 0.7 + 0.3
  }));

  return (
    <div className="stars-container">
      {stars.map((star) => (
        <div
          key={star.id}
          className="star"
          style={{
            top: star.top,
            left: star.left,
            width: star.size,
            height: star.size,
            '--duration': star.duration,
            '--delay': star.delay,
            '--opacity': star.opacity,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const App: React.FC = () => {
  // --- Session Management State ---
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  
  // Default to open on desktop, closed on mobile
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // --- Current Session State ---
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<ProcessingStatus>({ stage: 'idle' });
  
  // --- View State ---
  const [showMemoryGraph, setShowMemoryGraph] = useState(false);
  const [memorySnapshot, setMemorySnapshot] = useState({ memories: [], index: [] });
  
  // Exclusively Architect Mode State
  const [codingStep, setCodingStep] = useState(1); // 1 to 10
  const [isAutoPilot, setIsAutoPilot] = useState(false);
  const [useWebSearch, setUseWebSearch] = useState(true); 
  const [resetKey, setResetKey] = useState(0); 
  
  // Conversation Refinement State for Auto-Pilot
  const [refinementCount, setRefinementCount] = useState(0);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  // Initialize first session on load & handle initial sidebar state
  useEffect(() => {
    if (sessions.length === 0) {
      handleNewChat();
    }
    // Mobile check on mount
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  }, []);

  // Sync messages to current session
  useEffect(() => {
    if (currentSessionId) {
      setSessions(prev => prev.map(s => {
        if (s.id === currentSessionId) {
          // Generate a title from the first message if it's "New Chat"
          let title = s.title;
          if (s.title === 'New Chat' && messages.length > 0 && messages[0].content) {
            // Use user's first response as title, or the welcome message if needed (but usually user's first input)
            const firstUserMsg = messages.find(m => m.role === 'user');
            if (firstUserMsg) {
                 title = firstUserMsg.content.slice(0, 30) + (firstUserMsg.content.length > 30 ? '...' : '');
            }
          }
          return { 
            ...s, 
            messages, 
            codingStep, 
            isCodingMode: true, // Always true
            title,
            updatedAt: Date.now() 
          };
        }
        return s;
      }));
    }
  }, [messages, codingStep]);

  // Update memory snapshot when opening the graph
  useEffect(() => {
    if (showMemoryGraph) {
       // Sync latest data from service
       setMemorySnapshot({
         memories: memorySystem.getMemories() as any,
         index: memorySystem.getIndex() as any
       });
    }
  }, [showMemoryGraph, status]); // Also update when status changes (e.g. after save)

  // --- Session Handlers ---
  const handleNewChat = () => {
    const welcomeText = `Hello! Welcome to PROJECT-ELENCHOS.

I am your technical co-founder. To begin our collaboration, please select the project pathway that best fits your goals from the options below.`;

    const initialMessage: Message = {
      role: 'model',
      content: welcomeText,
      timestamp: Date.now()
    };

    const newSession: ChatSession = {
      id: crypto.randomUUID(),
      title: 'New Chat',
      messages: [initialMessage],
      updatedAt: Date.now(),
      isCodingMode: true,
      codingStep: 1
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    
    // Reset UI State
    setMessages([initialMessage]);
    setCodingStep(1);
    setRefinementCount(0);
    setIsAutoPilot(false);
    setUseWebSearch(true);
    setInput('');
    setStatus({ stage: 'idle' });
    
    // Auto-close on mobile only
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  const handleSelectChat = (id: string) => {
    const session = sessions.find(s => s.id === id);
    if (session) {
      setCurrentSessionId(id);
      setMessages(session.messages);
      setCodingStep(session.codingStep || 1);
      setRefinementCount(0);
      setIsAutoPilot(false);
      // Auto-close on mobile only
      if (window.innerWidth < 768) setIsSidebarOpen(false);
    }
  };

  const handleDeleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Delete this chat?')) {
      const newSessions = sessions.filter(s => s.id !== id);
      setSessions(newSessions);
      if (currentSessionId === id) {
        if (newSessions.length > 0) {
          handleSelectChat(newSessions[0].id);
        } else {
          handleNewChat();
        }
      }
    }
  };

  // --- Benchmark Logic ---
  const handleBenchmark = async () => {
    if (status.stage !== 'idle') return;
    if (!window.confirm("Run Architectural Benchmark? This will simulate a complex coding task using both 'Standard' and 'Architect' approaches, then rigorously judge the results. This takes a few seconds.")) return;

    setStatus({ stage: 'generating', details: 'Running Benchmark: Standard vs Architect...' });
    
    // 1. Add User Message
    const userMsg: Message = {
      role: 'user',
      content: "Run Benchmark: Compare standard coding vs Project Elenchos architecture.",
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      // 2. Run the Comparison (Parallel generation & Judging)
      const judgeReport = await runBenchmarkComparison();
      
      const modelMsg: Message = {
        role: 'model',
        content: judgeReport,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, modelMsg]);

    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'model', content: "Benchmark Failed due to API error.", timestamp: Date.now() }]);
    } finally {
      setStatus({ stage: 'idle' });
    }
  };

  // --- Auto-Pilot Logic (Agentic Conversation Loop) ---
  useEffect(() => {
    if (isAutoPilot && status.stage === 'idle' && messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'model' && codingStep < 10) {
        
        // Wait to simulate thinking/reading
        const timer = setTimeout(() => {
          
          // CRITICAL STEPS (5: Blueprint, 7: Execution) get 2 rounds of "talking" (Refinement)
          // Other steps get 1 round.
          const multiRoundSteps = [5, 7];
          const maxRefinements = multiRoundSteps.includes(codingStep) ? 2 : 1;

          if (refinementCount < maxRefinements && codingStep > 1) {
            handleRefinementCritique();
          } else {
            handleNextStep();
          }

        }, 4000); 
        return () => clearTimeout(timer);
      } else if (codingStep >= 10) {
        setIsAutoPilot(false); 
      }
    }
  }, [messages, status.stage, isAutoPilot, codingStep, refinementCount]);

  const getAutoPilotCritique = (step: number, currentRound: number) => {
    // Round 0 = Initial Critique
    // Round 1 = Optimization/Fix Command
    const isRoundTwo = currentRound === 1;

    switch (step) {
      case 2: 
        return "**LEAD ANALYST CHECK:** Check the Agreement. Does it have the Negative Constraint List? Ensure Includes/Excludes are binary.";
      
      case 3: 
        return "**SYSTEM DESIGNER CHECK:** Verify the Draft. Does it use Recursive Summarization? Ensure the Stack and Vibe are set.";
      
      case 4: 
        return "**TECH LEAD CHECK:** Verify the Research. Are the library versions real? Kill any hallucinations using the MCP/Search results.";
      
      case 5: // Blueprint - Enhanced Dialogue
        if (!isRoundTwo) return "**CHIEF ARCHITECT CHECK (Round 1):** Review the JSON-RPC Schema. Is every function and type defined? Identify gaps.";
        return "**CHIEF ARCHITECT CHECK (Round 2):** Finalize the Schema. Ensure Strict Enforcement is ready for Step 6.";

      case 6: 
        return "**PROJECT MANAGER CHECK:** Check Token-Density. Are the Micro-Prompts truly atomic? Verify the 'Instructional Gibberlink' pointers.";

      case 7: // Execution - Enhanced Dialogue
        if (!isRoundTwo) return "**BUILDER CHECK (Round 1):** Review the code. Did it respect the Constrained Generation? Any extra features added?";
        return "**BUILDER CHECK (Round 2):** Fix any deviations. Output ONLY the atomic code.";

      case 8: 
        return "**QA ENGINEER CHECK:** Run Semantic Differential Analysis. Compare Code vs Blueprint. Be blind to intent, focus on schema compliance.";

      case 9: 
        return "**LIBRARIAN CHECK:** Generate Dual Indices. Ensure Index A (Plan) and Index B (Reality) are distinct vectors.";
      
      default: 
        return "**ENGINE CHECK:** Verify logic constraints.";
    }
  };

  const handleRefinementCritique = async () => {
    const critique = getAutoPilotCritique(codingStep, refinementCount);
    setRefinementCount(prev => prev + 1);
    await handleSend(critique, true);
  };

  const handleClear = () => {
    if (window.confirm("WARNING: This will wipe ALL neural memories and ALL chat sessions. Continue?")) {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }

      memorySystem.clear();
      setResetKey(prev => prev + 1);

      setSessions([]);
      handleNewChat(); // Creates fresh session and resets state
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setStatus({ stage: 'idle', details: 'Cancelled by user' });
      setIsAutoPilot(false);
    }
  };

  const handleManualMemorySave = async () => {
    if (messages.length < 2) return;
    setStatus({ stage: 'updating-memory', details: 'Manually saving context...' });
    const recentContext = messages.slice(-4).map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n');
    await memorySystem.memorize(recentContext, null);
    setStatus({ stage: 'idle' });
    alert("Current context saved to Neural Memory.");
  };

  const handleNextStep = async () => {
    if (codingStep >= 10) return;

    // --- CRITICAL ARCHITECTURE FIX: Auto-Save High-Value Artifacts ---
    const lastModelMsg = messages[messages.length - 1];
    
    // Auto-Save Blueprint (Step 5)
    if (codingStep === 5 && lastModelMsg.role === 'model') {
       setStatus({ stage: 'updating-memory', details: 'Archiving Master Blueprint...' });
       await memorySystem.memorize(`[MASTER BLUEPRINT ARCHIVE]\n${lastModelMsg.content}`, null);
    }

    // Auto-Save Audit Log (Step 8) -- NEW: Essential for Step 9 "Dual Indexing"
    if (codingStep === 8 && lastModelMsg.role === 'model') {
      setStatus({ stage: 'updating-memory', details: 'Archiving Audit Log...' });
      await memorySystem.memorize(`[AUDIT LOG ARCHIVE]\n${lastModelMsg.content}`, null);
   }

    // Auto-Save Index (Step 9)
    if (codingStep === 9 && lastModelMsg.role === 'model') {
       setStatus({ stage: 'updating-memory', details: 'Saving Project Index...' });
       await memorySystem.memorize(`[SEMANTIC INDEX ARCHIVE]\n${lastModelMsg.content}`, null);
    }
    // -----------------------------------------------------------------
    
    const nextStep = codingStep + 1;
    setCodingStep(nextStep);
    setRefinementCount(0); // Reset refinement for the new step
    
    // "Technical Advisor" Persona Logic - Moving to the NEXT phase
    let triggerPrompt = "";
    switch(nextStep) {
      case 2: 
          triggerPrompt = "**LEAD ANALYST:** Use Case Locked. Proceed to **Step 2 (The Agreement)**. Define Includes/Excludes and Negative Constraints. Output A2A Point."; 
          break;
      case 3: 
          triggerPrompt = "**SYSTEM DESIGNER:** Agreement Sealed. Proceed to **Step 3 (Drafting)**. Summarize Architecture. Output A2A Point."; 
          break;
      case 4: 
          triggerPrompt = "**TECH LEAD:** Draft Ready. Proceed to **Step 4 (Research)**. Validate libraries via Search. Kill Hallucinations. Output A2A Point."; 
          break;
      case 5: 
          triggerPrompt = "**CHIEF ARCHITECT:** Research Done. Proceed to **Step 5 (Master Blueprint)**. Generate JSON-RPC Schema. Define all files. Output A2A Point."; 
          break;
      case 6: 
          triggerPrompt = "**PROJECT MANAGER:** Blueprint Active. Proceed to **Step 6 (Micro-Prompting)**. Break down into atomic tasks. Use Gibberlink. Output A2A Point."; 
          break;
      case 7: 
          triggerPrompt = "**JUNIOR DEVELOPER:** Prompts Ready. Proceed to **Step 7 (Execution)**. Build the first task. No creativity. Output A2A Point."; 
          break;
      case 8: 
          triggerPrompt = "**QA ENGINEER:** Code Built. Proceed to **Step 8 (Blind Audit)**. Compare against Blueprint. Blind Check. Output A2A Point."; 
          break;
      case 9: 
          triggerPrompt = "**LIBRARIAN:** Audit Complete. Proceed to **Step 9 (Dual Indexing)**. Store Plan vs Reality vectors. Output A2A Point."; 
          break;
      case 10: 
          triggerPrompt = "**PRODUCT OWNER:** Indexing Done. Proceed to **Step 10 (Alignment)**. Gap Analysis. Verdict. Output A2A Point."; 
          break;
    }
    
    if (triggerPrompt) {
      await handleSend(triggerPrompt, true);
    }
  };

  const handleSend = async (overrideInput?: string, isAutoTrigger: boolean = false) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim()) return;

    if (status.stage !== 'idle') handleCancel();

    const controller = new AbortController();
    abortControllerRef.current = controller;

    if (!isAutoTrigger) setInput('');

    const newMsg: Message = { role: 'user', content: textToSend, timestamp: Date.now() };
    setMessages(prev => [...prev, newMsg]);

    try {
      let context = "";
      
      // Architect Logic: Check memory specifically on Step 1 to ground the session
      if (codingStep === 1) {
        setStatus({ stage: 'embedding', details: 'Vectorizing input...' });
        await new Promise(r => setTimeout(r, 300)); 
        
        setStatus({ stage: 'checking-index', details: 'Scanning Index...' });
        const recallResult = await memorySystem.recall(textToSend);
        context = recallResult.context;
      }

      // Step 4 (Research) enables search
      const shouldSearch = useWebSearch || (codingStep === 4);

      setStatus({ stage: 'generating', details: shouldSearch ? 'Searching Web & Thinking...' : `PROJECT-ELENCHOS Step ${codingStep}...` });
      
      const currentHistory = [...messages, newMsg]; 

      // Always pass isCodingMode = true
      const response = await generateChatResponse(
        textToSend, 
        context, 
        true, 
        codingStep,
        currentHistory,
        controller.signal,
        shouldSearch
      );
      
      if (controller.signal.aborted) return;

      const replyMsg: Message = { 
        role: 'model', 
        content: response.text, 
        timestamp: Date.now(),
        sources: response.sources
      };
      setMessages(prev => [...prev, replyMsg]);

      // Note: Architect mode typically doesn't auto-memorize every turn to keep the memory clean, 
      // relying on the specific "Indexing" step (Step 9) or manual saves.

      setStatus({ stage: 'idle' });

    } catch (error) {
      if (controller.signal.aborted) return;
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', content: "Error: System Malfunction.", timestamp: Date.now() }]);
      setStatus({ stage: 'idle' });
      setIsAutoPilot(false); 
    } finally {
      abortControllerRef.current = null;
    }
  };

  // --- APP RENDER ---
  return (
    <div className="h-[100dvh] w-full relative flex font-sans text-slate-200 bg-[#050505] overflow-hidden">
      <StarField />
      
      {/* Sidebar */}
      <Sidebar 
        sessions={sessions}
        currentSessionId={currentSessionId}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative z-10 transition-all duration-300">
        
        {/* Header */}
        <header className="flex-none flex items-center justify-between p-4 md:p-6 border-b border-neutral-800/50 bg-neutral-900/30 backdrop-blur-sm">
          <div className="flex items-center gap-3">
             <button 
               onClick={() => setIsSidebarOpen(!isSidebarOpen)}
               className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
               title={isSidebarOpen ? "Close Sidebar" : "Open Sidebar"}
             >
               <PanelLeft size={20} className={!isSidebarOpen ? 'text-cyan-500' : ''} />
             </button>
             <div className="hidden md:flex items-center gap-2 text-sm font-medium text-neutral-400">
                <span className="text-cyan-500 font-bold">ARCHITECT MODE</span>
                <span className="w-1 h-1 rounded-full bg-neutral-600" />
                <span>{sessions.find(s => s.id === currentSessionId)?.title || 'New Chat'}</span>
             </div>
          </div>

          <div className="flex items-center gap-2 md:gap-3">
            {/* BENCHMARK BUTTON */}
            <button
              onClick={handleBenchmark}
              disabled={status.stage !== 'idle'}
              className="flex items-center justify-center gap-2 px-3 py-1.5 bg-amber-900/20 hover:bg-amber-800/40 text-amber-500 border border-amber-800/30 rounded-lg transition-all text-xs font-medium"
              title="Run a Benchmark Test"
            >
              <FlaskConical size={14} />
              <span className="hidden sm:inline">Benchmark</span>
            </button>

            <button
              onClick={() => setIsAutoPilot(!isAutoPilot)}
              disabled={codingStep >= 10}
              className={`flex items-center justify-center gap-2 px-3 py-1.5 border rounded-lg transition-all text-xs font-medium ${isAutoPilot ? 'bg-cyan-500 text-white border-cyan-400 animate-pulse' : 'bg-cyan-900/30 hover:bg-cyan-800/50 text-cyan-300 border-cyan-700/50'}`}
            >
              {isAutoPilot ? <Pause size={14} fill="currentColor" /> : <Play size={14} />}
              <span className="hidden sm:inline">{isAutoPilot ? 'Auto-Pilot ON' : 'Auto-Run'}</span>
            </button>

            {/* Neural Map Toggle */}
            <button
              onClick={() => setShowMemoryGraph(!showMemoryGraph)}
              className={`flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg transition-all text-xs font-medium border ${showMemoryGraph ? 'bg-emerald-900/30 text-emerald-300 border-emerald-700/50' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-400 border-neutral-700'}`}
              title="Toggle Neural Map"
            >
              <Activity size={14} className={showMemoryGraph ? 'animate-pulse' : ''} />
              <span className="hidden sm:inline">Neural Map</span>
            </button>

            <button
              onClick={handleManualMemorySave}
              className="flex items-center justify-center gap-2 px-3 py-1.5 bg-cyan-900/30 hover:bg-cyan-800/50 text-cyan-300 border border-cyan-700/50 rounded-lg transition-all text-xs font-medium"
            >
              <Save size={14} />
              <span className="hidden sm:inline">Save</span>
            </button>

            <button
              onClick={handleClear}
              className="flex items-center justify-center gap-2 px-3 py-1.5 bg-red-950/30 hover:bg-red-900/50 text-red-400 border border-red-900/30 hover:border-red-500/50 rounded-lg transition-all text-xs font-medium group"
            >
              <Trash2 size={14} />
              <span className="hidden sm:inline">Wipe All</span>
            </button>
          </div>
        </header>

        {/* Content Grid */}
        <main className="flex-1 flex flex-col h-full overflow-hidden p-0 md:p-4 lg:p-6 relative">
           
           {/* Chat View */}
           <div className={`absolute inset-0 p-0 md:p-4 lg:p-6 transition-all duration-500 ${showMemoryGraph ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'}`}>
             <ChatArea 
                key={resetKey}
                messages={messages}
                input={input}
                setInput={setInput}
                onSend={(text) => handleSend(text)}
                onCancel={handleCancel}
                status={status}
                codingStep={codingStep}
                onNextStep={handleNextStep}
                isAutoPilot={isAutoPilot}
                useWebSearch={useWebSearch}
                setUseWebSearch={setUseWebSearch}
             />
           </div>

           {/* Memory Graph View */}
           <div className={`absolute inset-0 p-0 md:p-4 lg:p-6 transition-all duration-500 ${!showMemoryGraph ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'}`}>
              <MemoryVisualizer 
                 memories={memorySnapshot.memories}
                 index={memorySnapshot.index}
                 activeTopicId={null} 
              />
           </div>

        </main>
      </div>
    </div>
  );
};

export default App;
