
import React, { useRef, useEffect, useState } from 'react';
import { Message, ProcessingStatus } from '../types';
import { Send, Bot, User, Loader2, Terminal, Code2, Copy, Check, ArrowDown, Sparkles, MessageSquare, Square, ArrowRight, FileText, Search, ScrollText, List, Play, Globe, ShieldCheck, Database, LayoutTemplate, Target, Music, Video, Image as ImageIcon, BrainCircuit, Microscope } from 'lucide-react';

// --- Markdown Utilities ---
const CodeBlock: React.FC<{ code: string; language?: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="my-4 rounded-lg overflow-hidden border border-neutral-700 bg-[#0d1117] shadow-sm group max-w-full">
      <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-neutral-700">
        <span className="text-xs text-neutral-400 font-mono">{language || 'code'}</span>
        <button onClick={handleCopy} className="text-neutral-400 hover:text-white transition-colors opacity-0 group-hover:opacity-100" title="Copy code">
          {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
        </button>
      </div>
      <div className="p-4 overflow-x-auto">
        <code className="font-mono text-sm text-cyan-300 whitespace-pre">{code}</code>
      </div>
    </div>
  );
};

const FormattedText: React.FC<{ text: string }> = ({ text }) => {
  const codeBlockRegex = /```(\w+)?\s*([\s\S]*?)```/g;
  const parts = [];
  let lastIndex = 0;
  let match;
  while ((match = codeBlockRegex.exec(text)) !== null) {
    if (match.index > lastIndex) parts.push({ type: 'text', content: text.slice(lastIndex, match.index) });
    parts.push({ type: 'code', language: match[1], content: match[2] });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < text.length) parts.push({ type: 'text', content: text.slice(lastIndex) });

  return (
    <>
      {parts.map((part, idx) => {
        if (part.type === 'code') return <CodeBlock key={idx} code={part.content} language={part.language} />;
        const lines = part.content.split('\n');
        return (
          <div key={idx} className="whitespace-pre-wrap text-slate-300 break-words">
            {lines.map((line, lineIdx) => {
              if (line.startsWith('### ')) return <h3 key={lineIdx} className="text-lg font-semibold text-lime-400 mt-6 mb-2">{line.replace('### ', '')}</h3>;
              if (line.startsWith('## ')) return <h2 key={lineIdx} className="text-xl font-bold text-lime-300 mt-6 mb-3 border-b border-lime-900/30 pb-1">{line.replace('## ', '')}</h2>;
              if (line.startsWith('** Step')) return <h3 key={lineIdx} className="text-md font-bold text-cyan-400 mt-5 mb-2">{line.replace(/\*\*/g, '')}</h3>;
              // Handle Markdown Links [Title](URL)
              if (line.includes('[') && line.includes('](')) {
                  const linkParts = line.split(/(\[.*?\]\(.*?\))/g);
                  return (
                    <p key={lineIdx} className="leading-relaxed mb-1">
                      {linkParts.map((part, pIdx) => {
                        const linkMatch = part.match(/\[(.*?)\]\((.*?)\)/);
                        if (linkMatch) {
                           return <a key={pIdx} href={linkMatch[2]} target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 underline underline-offset-2">{linkMatch[1]}</a>
                        }
                        return parseInlineStyles(part);
                      })}
                    </p>
                  )
              }
              if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
                return <div key={lineIdx} className="flex gap-3 ml-1 my-1.5"><span className="text-neutral-500 mt-1.5 w-1.5 h-1.5 rounded-full bg-neutral-600 shrink-0 block"></span><span className="leading-relaxed">{parseInlineStyles(line.replace(/^[\*\-]\s+/, ''))}</span></div>;
              }
              if (line.trim() === '') return <div key={lineIdx} className="h-2" />;
              return <p key={lineIdx} className="leading-relaxed mb-1">{parseInlineStyles(line)}</p>;
            })}
          </div>
        );
      })}
    </>
  );
};

const parseInlineStyles = (text: string) => {
  const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) return <strong key={i} className="text-white font-semibold">{part.slice(2, -2)}</strong>;
    if (part.startsWith('`') && part.endsWith('`')) return <code key={i} className="bg-[#1e242c] text-lime-300 px-1.5 py-0.5 rounded text-xs font-mono border border-neutral-700/50 break-all">{part.slice(1, -1)}</code>;
    return part;
  });
};

// --- Main Component ---

interface ChatAreaProps {
  messages: Message[];
  input: string;
  setInput: (s: string) => void;
  onSend: (text?: string) => void;
  onCancel: () => void;
  status: ProcessingStatus;
  codingStep: number;
  onNextStep: () => void;
  isAutoPilot?: boolean;
  useWebSearch?: boolean;
  setUseWebSearch?: (v: boolean) => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({ 
  messages, 
  input, 
  setInput, 
  onSend,
  onCancel,
  status,
  codingStep,
  onNextStep,
  isAutoPilot,
  useWebSearch,
  setUseWebSearch
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      // Reset height to auto to get the correct scrollHeight for shrinking
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      // Cap at 200px
      textareaRef.current.style.height = `${Math.min(scrollHeight, 200)}px`;
    }
  }, [input]);

  // Smart Scroll Logic
  useEffect(() => {
    if (messages.length === 0) return;
    
    const container = scrollContainerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 150;
    const isNewUserMessage = messages[messages.length - 1].role === 'user';

    if (isNearBottom || isNewUserMessage) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, status]); 

  const handleScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
      setShowScrollButton(scrollHeight - scrollTop - clientHeight > 100);
    }
  };

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  const isProcessing = status.stage !== 'idle';
  const containerMaxWidth = 'max-w-5xl';

  // Fixed top padding for the sticky step indicator
  const paddingTopClass = 'pt-24 md:pt-28';

  const stepLabels = [
    { id: 1, label: 'Use Case', icon: Target },
    { id: 2, label: 'Agreement', icon: MessageSquare },
    { id: 3, label: 'Draft', icon: FileText },
    { id: 4, label: 'Research', icon: Search },
    { id: 5, label: 'Blueprint', icon: ScrollText },
    { id: 6, label: 'Prompts', icon: List },
    { id: 7, label: 'Execute', icon: Terminal },
    { id: 8, label: 'Audit', icon: ShieldCheck },
    { id: 9, label: 'Index', icon: Database },
    { id: 10, label: 'Align', icon: LayoutTemplate },
  ];

  // Show selection options only on Step 1 if the conversation is at the start (just the welcome message)
  const showStep1Selection = codingStep === 1 && messages.length <= 1 && !isProcessing;

  return (
    <div className="flex flex-col h-full bg-neutral-900/80 backdrop-blur-md rounded-2xl shadow-2xl border border-neutral-800 overflow-hidden relative transition-all duration-500">
      
      {/* Top Bar - Step Indicator Only */}
      <div className="absolute top-0 left-0 right-0 z-20 p-2 md:p-4 flex flex-col items-center pointer-events-none gap-3">
        {/* Step Indicator */}
        <div className="pointer-events-auto flex items-center gap-1 md:gap-2 bg-neutral-950/80 backdrop-blur border border-neutral-800 rounded-full px-2 py-1.5 md:py-2 shadow-2xl overflow-x-auto max-w-[95vw] scrollbar-hide">
          {stepLabels.map((s) => {
              const isActive = s.id === codingStep;
              const isPast = s.id < codingStep;
              const Icon = s.icon;
              return (
                <div key={s.id} className={`flex items-center gap-1.5 px-2 md:px-3 py-1 rounded-full transition-all ${isActive ? 'bg-cyan-900/30 text-cyan-300 border border-cyan-500/20' : isPast ? 'text-cyan-700' : 'text-neutral-600'}`}>
                  <Icon size={12} className={isActive ? 'animate-pulse' : ''} />
                  <span className={`text-[10px] font-bold whitespace-nowrap ${!isActive && 'hidden md:inline'}`}>{s.label}</span>
                  {isPast && <Check size={10} className="text-cyan-500 ml-1" />}
                </div>
              );
          })}
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollContainerRef} 
        onScroll={handleScroll} 
        className={`flex-1 overflow-y-auto px-3 md:px-4 ${paddingTopClass} pb-4 space-y-6 md:space-y-8 scrollbar-thin scrollbar-thumb-neutral-700 scrollbar-track-transparent overscroll-contain touch-pan-y`}
      >
        {messages.map((msg, idx) => {
          return (
            <div key={idx} className={`flex gap-3 md:gap-4 ${containerMaxWidth} mx-auto ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role === 'model' && (
                 <div className="w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center flex-shrink-0 border mt-1 shadow-lg bg-cyan-950 text-cyan-400 border-cyan-900">
                   <Terminal size={12} />
                 </div>
              )}
              
              <div className={`group relative max-w-[85%] sm:max-w-[90%] text-xs md:text-sm leading-relaxed shadow-md ${msg.role === 'user' ? 'bg-[#2F2F2F] text-slate-200 rounded-2xl rounded-tr-sm px-4 py-2 md:px-5 md:py-3 border border-neutral-700/50' : 'bg-transparent text-slate-300 px-0 py-0'}`}>
                
                {msg.role === 'user' ? msg.content : <FormattedText text={msg.content} />}

                {/* Sources / Grounding Data */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2 animate-in fade-in slide-in-from-bottom-2">
                    <div className="w-full flex items-center gap-1.5 mb-1 opacity-70">
                       <Search size={10} className="text-cyan-400" />
                       <span className="text-[10px] font-bold text-cyan-500 uppercase tracking-widest">Sources</span>
                    </div>
                    {msg.sources.map((source, i) => (
                      <a 
                        key={i} 
                        href={source.uri} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="flex items-center gap-1.5 bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700/50 hover:border-cyan-500/30 text-neutral-300 hover:text-cyan-300 text-[10px] px-2.5 py-1.5 rounded-full transition-all group/source"
                      >
                        <Globe size={10} className="text-neutral-500 group-hover/source:text-cyan-400" />
                        <span className="truncate max-w-[150px]">{source.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>

              {msg.role === 'user' && (
                 <div className="w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center flex-shrink-0 border border-neutral-700 bg-neutral-800 text-neutral-400 mt-1 shadow-lg"><User size={12} /></div>
              )}
            </div>
          );
        })}

        {/* Interactive Selection Cards for Step 1 (Appearing after the welcome message) */}
        {showStep1Selection && (
             <div className={`${containerMaxWidth} mx-auto pl-10 md:pl-12 mt-4 animate-in slide-in-from-bottom-4 duration-700 fade-in fill-mode-forwards`}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button 
                      onClick={() => onSend("I want to start a Coding Project.")}
                      className="flex flex-col text-left p-5 bg-neutral-800/40 backdrop-blur-sm border border-neutral-700/50 hover:border-cyan-500/50 hover:bg-neutral-800/60 rounded-2xl transition-all group shadow-xl hover:-translate-y-1 hover:shadow-cyan-900/20"
                    >
                       <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center group-hover:scale-110 group-hover:bg-blue-500/20 transition-all">
                             <Code2 size={20} />
                          </div>
                          <span className="text-slate-200 font-bold text-base group-hover:text-blue-300 transition-colors">Coding</span>
                       </div>
                       <p className="text-xs text-neutral-400 leading-relaxed group-hover:text-neutral-300 transition-colors">
                          Development of a software feature, application, tool, or complex system.
                       </p>
                    </button>

                    <button 
                      onClick={() => onSend("I want to start a Research Project.")}
                      className="flex flex-col text-left p-5 bg-neutral-800/40 backdrop-blur-sm border border-neutral-700/50 hover:border-purple-500/50 hover:bg-neutral-800/60 rounded-2xl transition-all group shadow-xl hover:-translate-y-1 hover:shadow-purple-900/20"
                    >
                       <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center group-hover:scale-110 group-hover:bg-purple-500/20 transition-all">
                             <Microscope size={20} />
                          </div>
                          <span className="text-slate-200 font-bold text-base group-hover:text-purple-300 transition-colors">Research</span>
                       </div>
                       <p className="text-xs text-neutral-400 leading-relaxed group-hover:text-neutral-300 transition-colors">
                          In-depth analysis, literature review, or exploration of a technical topic.
                       </p>
                    </button>

                    <button 
                      onClick={() => onSend("I want to start a Custom Project.")}
                      className="flex flex-col text-left p-5 bg-neutral-800/40 backdrop-blur-sm border border-neutral-700/50 hover:border-emerald-500/50 hover:bg-neutral-800/60 rounded-2xl transition-all group shadow-xl hover:-translate-y-1 hover:shadow-emerald-900/20"
                    >
                       <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center group-hover:scale-110 group-hover:bg-emerald-500/20 transition-all">
                             <Sparkles size={20} />
                          </div>
                          <span className="text-slate-200 font-bold text-base group-hover:text-emerald-300 transition-colors">Custom</span>
                       </div>
                       <p className="text-xs text-neutral-400 leading-relaxed group-hover:text-neutral-300 transition-colors">
                          Something unique that doesn't fit neatly into the standard categories.
                       </p>
                    </button>
                </div>

                <button
                  onClick={() => onSend("I'm feeling lucky! Generate a unique, creative, and fully-formed app idea for me to build.")}
                  className="w-full mt-4 flex items-center justify-center gap-3 p-4 bg-gradient-to-r from-indigo-500/20 via-purple-500/20 to-pink-500/20 hover:from-indigo-500/30 hover:via-purple-500/30 hover:to-pink-500/30 border border-indigo-500/30 hover:border-indigo-400/50 rounded-2xl transition-all group shadow-lg hover:shadow-indigo-900/20"
                >
                  <div className="p-1 rounded-full bg-gradient-to-r from-indigo-400 to-pink-400 text-white shadow-lg group-hover:scale-110 transition-transform">
                     <Sparkles size={16} className="animate-pulse" />
                  </div>
                  <span className="text-indigo-200 font-bold group-hover:text-indigo-100">I'm Feeling Lucky &mdash; Generate a Random Idea</span>
                </button>
             </div>
        )}

        {isProcessing && (
          <div className={`flex gap-4 ${containerMaxWidth} mx-auto`}>
             <div className="w-8 h-8 rounded-full flex items-center justify-center border border-opacity-20 animate-pulse bg-cyan-950 text-cyan-500 border-cyan-500">
              <Code2 size={14} />
            </div>
            <div className="flex items-center gap-3 text-xs font-mono mt-2">
              <Loader2 size={14} className="animate-spin text-cyan-500" />
              <span className="uppercase tracking-widest opacity-70 text-cyan-500">{status.stage.replace(/-/g, ' ')}...</span>
              <button onClick={onCancel} className="ml-2 flex items-center gap-1 bg-red-900/20 hover:bg-red-900/40 text-red-400 px-2 py-1 rounded text-[10px] border border-red-900/30 transition-colors">
                <Square size={8} fill="currentColor" /> STOP
              </button>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {showScrollButton && <button onClick={scrollToBottom} className="absolute bottom-24 md:bottom-28 left-1/2 -translate-x-1/2 z-30 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 rounded-full p-2 shadow-lg transition-all animate-in fade-in slide-in-from-bottom-2"><ArrowDown size={16} /></button>}

      {/* Input Area */}
      <div className="flex-none p-3 md:p-4 lg:p-6 relative z-30 bg-gradient-to-t from-neutral-900 via-neutral-900/95 to-transparent pt-8 md:pt-10">
        <div className={`${containerMaxWidth} mx-auto relative transition-all duration-500`}>
          
          {/* Step Action Button */}
          {!isProcessing && codingStep < 10 && messages.length > 0 && messages[messages.length-1].role === 'model' && !isAutoPilot && (
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-40">
               <button 
                 onClick={onNextStep}
                 className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-full shadow-[0_0_15px_rgba(8,145,178,0.5)] text-xs font-bold uppercase tracking-wider border border-cyan-400 transition-all"
               >
                 {codingStep === 1 ? 'Start Agreement' : 
                  codingStep === 2 ? 'Create Draft' : 
                  codingStep === 3 ? 'Start Research' :
                  codingStep === 4 ? 'Create Blueprint' :
                  codingStep === 5 ? 'Gen Micro-Prompts' :
                  codingStep === 6 ? 'Start Execution' :
                  codingStep === 7 ? 'Run Blind Audit' :
                  codingStep === 8 ? 'Index Code' :
                  'Check Alignment'}
                 <ArrowRight size={14} />
               </button>
            </div>
          )}
          
          {/* Auto-Pilot Indicator */}
          {isAutoPilot && isProcessing && (
             <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-40">
               <div className="flex items-center gap-2 bg-cyan-900/80 text-cyan-300 px-4 py-2 rounded-full border border-cyan-500/30 shadow-xl animate-pulse">
                 <Play size={14} fill="currentColor" />
                 <span className="text-xs font-bold uppercase tracking-widest">Auto-Pilot Active</span>
               </div>
             </div>
          )}

          <div className="relative flex items-end rounded-3xl bg-[#1a1a1a] border shadow-xl transition-colors overflow-hidden border-cyan-900/30 focus-within:border-cyan-500/30">
            {/* Search Toggle */}
            {setUseWebSearch && (
              <button 
                onClick={() => setUseWebSearch(!useWebSearch)} 
                className={`ml-2 mb-2 p-2 rounded-full transition-all ${useWebSearch ? 'text-cyan-400 bg-cyan-950/50' : 'text-neutral-500 hover:text-neutral-300 hover:bg-neutral-800'}`}
                title={useWebSearch ? "Search Enabled" : "Enable Web Search"}
              >
                <Globe size={18} />
              </button>
            )}

            <textarea
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isAutoPilot ? "Auto-Pilot running..." : (codingStep === 10 ? "Discuss alignment..." : `Step ${codingStep}: Discuss current task...`)}
              disabled={isProcessing || isAutoPilot}
              className="flex-1 bg-transparent text-slate-200 text-sm md:text-[15px] w-full pl-3 md:pl-4 pr-12 md:pr-14 py-3 md:py-4 outline-none disabled:opacity-50 placeholder-neutral-500 resize-none overflow-hidden min-h-[50px] max-h-[200px]"
              style={{ height: 'auto' }}
            />
            <button onClick={() => onSend()} disabled={!input.trim() || isProcessing} className="absolute right-2 bottom-2 p-1.5 md:p-2 rounded-full transition-all disabled:opacity-30 disabled:scale-90 bg-cyan-600 text-white hover:bg-cyan-500 shadow-[0_0_10px_rgba(8,145,178,0.4)]">
              {isProcessing ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            </button>
          </div>
          
          <div className="text-center mt-2 md:mt-3">
            <p className="text-[10px] text-neutral-600">Gemini can make mistakes. Consider checking important information.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
